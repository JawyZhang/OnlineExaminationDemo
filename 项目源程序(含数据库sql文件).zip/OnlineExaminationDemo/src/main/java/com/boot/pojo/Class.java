package com.boot.pojo;

public class Class {
    private Course theCourse;
    private Student student;

    public Course getTheClass() {
        return theCourse;
    }

    public void setTheClass(Course theClass) {
        this.theCourse = theCourse;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
}
