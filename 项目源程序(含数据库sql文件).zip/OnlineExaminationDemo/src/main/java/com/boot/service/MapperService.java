package com.boot.service;

import com.boot.pojo.Teacher;

import java.util.List;

/**
 * @Author Mango
 * @Date 2020-04-15 22:15
 */
public interface MapperService {
    List<Teacher> testSelectAllTeacher();
}
